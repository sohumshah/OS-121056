read a
read b
sum=`expr $a + $b`
echo "Sum="$sum
diff=`expr $a - $b`
echo "Difference="$diff
prod=`expr $a \* $b`
echo "Product="$prod
quo=$((a / b))
echo "Quotient="$quo
rem=$((a % b))
echo "Remainder="$rem

