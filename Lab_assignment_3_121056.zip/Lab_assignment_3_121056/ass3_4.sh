read a
read b
if [ $a -gt $b ]
then echo "first number is greater"
elif [ $b -gt $a ]
then echo "second number is greater"
else echo "numbers are equal"
fi
