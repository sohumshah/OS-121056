read a
read op
read b
case $op in
+) sum=`expr $a + $b`
echo $sum;;
-) diff=`expr $a - $b`
echo $diff;;
x) prod=`expr $a \* $b`
echo $prod;;
/) quo=$((a / b))
echo $quo;;
%) rem=$((a % b))
echo $rem;;

esac
