echo Enter the number to be checked
read n1
array_num=( '1' '11' '25' '67' '50')
for (( i=0; i <= 4; i++ ))
do
if [ $n1 = ${array_num[i]} ]
then
echo the num is present at position $i
exit
fi
done
if [ $i -eq 5 ]
then echo number not found
fi
