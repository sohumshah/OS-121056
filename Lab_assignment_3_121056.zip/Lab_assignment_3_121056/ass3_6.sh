echo "enter command name"
read a
echo "enter value to be executed"
read b
$a $b
