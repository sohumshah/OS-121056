while [ 1 ]
do
read a
if [ $a \< 51 ]
then sq=`expr $a \* $a`
echo "Square of num:"$sq
else echo "enter no. less than 51"
fi
echo "Enter 0 to exit, 1 to continue"
read cont
if [ $cont -eq 0 ]
then exit
fi
done
