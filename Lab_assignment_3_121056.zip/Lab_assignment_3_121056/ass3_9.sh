echo "Enter the capital of Gujarat"
while [ 1 ]
do
read a
if [ $a = "Gandhinagar" ]
then echo "correct answer"
exit
fi

if [ $a = "gandhinagar" ]
then echo "correct answer"
exit

else echo "Wrong answer,Try again"
fi
done
