#include<stdio.h>
void main()
{
	int R[5]; //Resource vector
	int V[5]; //Available vector
	int A[5][5]; //Allocated matrix
	int C[5][5]; //maximum claim matrix
	int need[5][5];
	int out[5][5];
	int i,j;
	int curr_proc=0;
	int trace[5];
	for(i=0;i<5;i++)
		trace[i]=-1;
	
	
	/*for(i=0;i<5;i++)
	{
		printf("Give total number of resource %d of system\n",i);
		scanf("%d",&R[i]);
	}*/
	for(i=0;i<5;i++)
	{
		printf("Give total number of resources of resource %d available in system currently\n",i);
		scanf("%d",&V[i]);
	}
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			printf("Give number of resource R%d allocated to process P%d\n",j,i);
			scanf("%d",&A[i][j]);
		}
	}
	
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			printf("Give total number of resource R%d claimed by process P%d\n",j,i);
			scanf("%d",&C[i][j]);
		}
	}
	printf("need:\n");
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			need[i][j]=C[i][j]-A[i][j];
			printf("%d ",need[i][j]);
		}
		printf("\n");
	}
	int index=0,deadlock=0;
	
	int check()
	{
		int curr,k,l,m,count;
		int temp2=0;
		for(k=0;k<5;k++)
		{
			count=0;
			for(l=0;l<5;l++)
			{
				if(V[l]>=need[k][l])
				count++;
				//printf("count: %d\n",count);
			}
			if(count==5)
			{
				temp2=0;
				for(m=0;m<5;m++)
				{
					if(trace[m]==k)
					{
						//printf("in if\n");
						temp2=1;
					}
				}
				if(temp2==0)
				{
					curr=k;
					return curr;
				}
			}
		}
		return -1;
	}
			
			
	
	while(1)
	{
		curr_proc=check();
		if(curr_proc==-1)
		{
			printf("Deadlock shall occur\n");
			deadlock=1;
			break;
		}
		//printf("Deadlock value: %d\n",deadlock);
		i=curr_proc;
		for(j=0;j<5;j++)
		{
			V[j]=V[j]-need[i][j];
			need[i][j]=0;
			V[j]=C[i][j]+V[j];
		}
		printf("P%d done\n",i);
		trace[index]=i;
		index++;
		if(index==5)
		{
			break;
		}
	}
	if(deadlock==0)
	for(i=0;i<5;i++)
	printf("P%d -> ",trace[i]);
}	
			
		
		
		
		
		
		
		
		
		
