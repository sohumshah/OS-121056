class get_put
{
	int n;
	boolean item = false;
	synchronized int get()
	{
		if(!item)
		{
			try
			{
				wait();
			}
			catch(InterruptedException e)
			{
				System.out.println("InterruptedException caught");
			}
		}

		System.out.println("Consume: " + n);
		item = false;
		notify();
		return n;
	}

	synchronized void put(int n)
	{
		if(item)
		try
		{
			wait();
		}
		catch(InterruptedException e)
		{
			System.out.println("InterruptedException caught");
		}

		this.n = n;
		item = true;
		System.out.println("Produce: " + n);
		notify();
	}
}

class Producer implements Runnable
{
	get_put q;
	Producer(get_put q)
	{
		this.q = q;
		new Thread(this, "Producer").start();
	}
	
	public void run()
	{
		int i = 0;
		while(i<=10)
		{
			q.put(i++);
		}
	}
}

class Consumer implements Runnable
{
	get_put q;
	Consumer(get_put q)
	{
		this.q = q;
		new Thread(this, "Consumer").start();
	}
	public void run()
	{
		while(true)
		{
			q.get();
		}
	}
}

class Producer_Consumer_monitor
{
	public static void main(String args[])
	{
		get_put q = new get_put();
		new Producer(q);
		new Consumer(q);
	}
}
