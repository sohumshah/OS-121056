#include<stdio.h>
#include<stdlib.h>

int item;
int queue[2]={0};
int semaphore=1;



void semwait()
{
	semaphore--;
}

void semsignal()
{
	semaphore++;
}
void enqueue(int b)
{
	int a=0,i;
	for(i=0;i<2;i++)
	{
		if(queue[i]==0)
		{
			a=1;
			queue[i]=b;
			break;
		}
	}
	if(a==0)
	{
		printf("\n\nQueue Full. Request Terminated!\n\n");
	}	
		
}

void dequeue()
{
	queue[0]=queue[1];
	queue[1]=0;	
}



void producer()
{
	semwait();
	if(item==0)
	{
		item=1;
		if(queue[0]!=0)
		{
			printf("\n\nConsumer %d consumed the item\n\n",queue[0]);
			dequeue();
			item=0;
		}
	}
	else if(item==1)
	{
		printf("\n\nBuffer Full, cant be produced!\n\n");
	} 
	semsignal();
}

void consumer1()
{
	int i,a=0;
	
	semwait();
	if(item==1)
	{
		item=0;
		printf("\n\nConsumer 1 consumed the item\n\n");
	}
	else if(item==0)
	{
		enqueue(1);
	}
	semsignal();
}

void consumer2()
{
	int i;
	int a=0;
		
	semwait();
	if(item==1)
	{
		item=0;
		printf("\n\nConsumer 2 consumed the item\n\n");
	}
	else if(item==0)
	{
		enqueue(2);
	}
	semsignal();
}

void queue_status()
{
	int i;
	for(i=0;i<2;i++)
	{
		printf("\n\n");
		if(queue[i]==1)
		{
			printf("%d. Consumer1\n", i+1);
		}
		else if(queue[i]==2)
		{
			printf("%d. Consumer2\n", i+1);
		}	
		else
		{
			printf("%d. Empty!\n", i+1);
		}
	}
}




void main()
{
	int choice;
	while(1)
	{
		printf("\n\n--------------------------------\n");	
		printf("1. Call Producer\n");
		printf("2. Call Consumer 1\n");
		printf("3. Call Consumer 2\n");
		printf("4. View Queue Status\n");
		printf("5. View item Buffer Status\n");
		printf("^Z for Exit\n");
		printf("\n---------------\n");
		printf("Enter Choice:");
		scanf("%d", &choice);
		switch(choice)
		{
			case 1:
				producer();
				break;
			case 2:
				consumer1();
				break;
			case 3:
				consumer2();
				break;
			case 4:
				queue_status();
			case 5:
				if(item==1)
				{
					printf("\nBuffer Full!\n");
				}
				else
				{
					printf("\nBuffer Empty\n");
				}
		}
	
	}	
}









