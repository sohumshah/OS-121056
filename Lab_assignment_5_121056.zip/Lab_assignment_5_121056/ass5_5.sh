echo Enter the first filename
read f1
echo Enter the second filename
read f2
if find $f1 
then 
cat $f1 >> $f2
else 
echo The first file doesnt exist
fi 
