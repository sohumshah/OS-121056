echo Enter the alphabet to search the file 
read a 
ls -a $a*
