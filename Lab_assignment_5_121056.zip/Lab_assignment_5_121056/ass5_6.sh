y=$1
if [ $y -lt 50 ]
then
echo The sum of first 50 numbers is 1275
else
n=` expr $1 + 1 `
k=` expr $1 \* $n `
ans=` expr $k / 2 `
echo $ans
fi
