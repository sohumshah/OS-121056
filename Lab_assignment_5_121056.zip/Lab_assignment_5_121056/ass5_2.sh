echo Enter the string
read str
y=` expr $str | rev `
echo $y
if [ "$str" = "$y" ]
then
echo It is a palindrome 
else
echo Not a palindrome
fi


