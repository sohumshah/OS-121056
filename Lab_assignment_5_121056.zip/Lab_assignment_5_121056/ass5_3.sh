y=$2
i=0
while [ $i -lt $y ]
do 
echo $1
i=` expr $i + 1 `
done
