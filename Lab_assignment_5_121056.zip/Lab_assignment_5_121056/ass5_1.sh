echo Reverse of the string is 
echo $1 | rev

